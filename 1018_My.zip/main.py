from MyAI import MyML

minsu = MyML()
minsu.set_file("male_female.csv")
minsu.set_data_ratio(0.2)
minsu.set_q_cols(['Weight', 'Height'])
minsu.set_target('Sex')
minsu.doML()




