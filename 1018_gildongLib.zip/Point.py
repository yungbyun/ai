class XXX: #gildong
    iX = 0
    iY = 0

    def Assign(self, a, b):
        self.iX = a
        self.iY = b

    def add(self):
        return self.iX + self.iY
